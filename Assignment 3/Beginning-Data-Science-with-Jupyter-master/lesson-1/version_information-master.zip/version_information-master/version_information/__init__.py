from __future__ import absolute_import
from version_information.version import version as __version__
from version_information.version_information import *
